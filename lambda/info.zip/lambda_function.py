import sys
import logging
import pymysql
import info
import json

connection = pymysql.connect(host=info.db_host,port=3306,
user=info.db_username,passwd=info.db_password,db=info.db_name)

def lambda_handler(event, context):
    cursor = connection.cursor()
    cursor.execute("insert into winner select * from user order by rand() limit 3")
    cursor.execute("select email from winner")
    cursor.close()

    connection.commit()

    rows = cursor.fetchall()

    for data in rows:
        print(data)

    cursor.close()