db_host = ""
db_username = "root"
db_password = "It12345!"
db_name = "random"
db_port = 3306